sap.ui.define([
	"ns/TestCLU/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
